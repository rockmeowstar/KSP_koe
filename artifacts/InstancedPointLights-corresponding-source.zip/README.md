# Corresponding source — instanced point-light module

This archive accompanies the GPL-3.0 shader-derived component in KOE 0.15.0.
Original Deferred copyright: Ghassen Lahmar, 2024-2025. Modifications by Ivan and
KOE contributors, 2026-11-04. Exact license texts are in `licenses/`.
KOE-authored source is also available under its MIT grant. The combined plugin
binary containing Deferred-derived shader assets is distributed with GPL-3.0
conditions; those assets are not relicensed under MIT.

The preferred form used to modify these shader programs is the included shader
assembly (`shader-sources/light[01]-[vp]s.asm`). Unmodified disassembly/bytecode,
signature/reflection inputs, generator scripts and original upstream source at
tag 1.3.3.0 are included. No network fetch is needed to obtain these sources.

Rebuild using PowerShell:

```powershell
./Build-PointLights.ps1 -GamePath 'D:/your/KSP' -Assembler 'D:/3dmigoto-1.3.16/cmd_Decompiler.exe'
```

Developer prerequisites: licensed KSP 1.12.5 installation, Windows SDK
10.0.26100.0, MSVC 14.51.36231, .NET Framework csc, and the general-purpose free
3Dmigoto cmd_Decompiler 1.3.16 assembler. The compiler/SDK paths in the two native
build scripts can be adjusted for a compatible developer installation.
3Dmigoto upstream: https://github.com/bo3b/3Dmigoto/releases/tag/1.3.16
These are developer prerequisites; the installed mod does not need them.

The script rebuilds the four modified shaders, checks their accepted hashes,
builds the native renderer and shared core, and creates the same wrapper/payload
layout. PE timestamps/managed module identities can differ between builds; the
shader bytes are checked exactly. No original game or mod binary is redistributed.

`LightContextHooks.generated.h` contains the generated typed D3D state barriers;
its generator is included. `LightShaders.generated.h` pins the known source and
replacement identities. Individual light constants and blending order are kept.
The production build excludes GPU readback/audit routines.
