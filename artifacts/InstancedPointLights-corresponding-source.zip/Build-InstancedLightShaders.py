"""Create diagnostic instanced variants without translating lighting arithmetic.

Every source keeps a separate 128-float4 constant record. Original VS/PS
instructions only change constant-buffer addressing; SV_InstanceID selects
the record. This is shader preparation, not an installed renderer.
"""
import argparse, hashlib, json, re, struct, subprocess
from pathlib import Path

def chunks(data):
    if data[:4]!=b'DXBC' or len(data)<32: raise ValueError('Not DXBC')
    count=struct.unpack_from('<I',data,28)[0]
    result=[]
    for offset in struct.unpack_from('<'+'I'*count,data,32):
        tag,size=struct.unpack_from('<4sI',data,offset)
        if offset+8+size>len(data): raise ValueError('Truncated DXBC chunk')
        result.append((tag,data[offset+8:offset+8+size]))
    return result

def add_signature(data,name,index,system,register,output=False):
    count,version=struct.unpack_from('<II',data)
    rows=[]
    for i in range(count):
        offset,*fields=struct.unpack_from('<6I',data,8+i*24)
        semantic=data[offset:data.index(b'\0',offset)]
        rows.append((semantic,fields))
    if any(x[1][3]==register or (x[0]==name.encode() and x[1][0]==index) for x in rows):
        raise ValueError('Instance signature collision')
    # D3D_REGISTER_COMPONENT_UINT32=1; outputs encode never-written components.
    rows.append((name.encode(),[index,system,1,register,0x0e01 if output else 0x0101]))
    strings=b''; table=b''; base=8+len(rows)*24
    for semantic,fields in rows:
        table+=struct.pack('<6I',base+len(strings),*fields)
        strings+=semantic+b'\0'
    signature=struct.pack('<II',len(rows),version)+table+strings
    return signature+b'\0'*((-len(signature))%4)

def signature_container(original,stage,input_register,output_register):
    result=[]
    for tag,data in chunks(original):
        if tag==b'ISGN':
            data=add_signature(data,'SV_InstanceID' if stage=='vs' else 'TEXCOORD',0 if stage=='vs' else 15,8 if stage=='vs' else 0,input_register)
        elif tag==b'OSGN' and stage=='vs':
            data=add_signature(data,'TEXCOORD',15,0,output_register,True)
        elif tag in (b'ISG1',b'OSG1',b'OSG5'): raise ValueError('Unsupported signature generation')
        result.append((tag,data))
    offsets=[]; body=b''; offset=32+4*len(result)
    for tag,data in result:
        offsets.append(offset+len(body)); body+=tag+struct.pack('<I',len(data))+data
        body+=b'\0'*((-len(body))%4)
    # Reflection input only; assembler builds a fresh container and checksum.
    return b'DXBC'+bytes(16)+struct.pack('<III',1,offset+len(body),len(result))+struct.pack('<'+'I'*len(result),*offsets)+body

def rewrite(text,stage,base):
    lines=[re.sub(r'^\s*\d+:\s*','',x).strip() for x in text.splitlines() if x.strip() and not x.startswith('Shader hash') and not x.lstrip().startswith('//')]
    if lines[0] not in ('vs_4_0','ps_4_0'): raise ValueError('Unverified shader model')
    if any(re.search(r'cb\d+\[[^\d]',x) for x in lines): raise ValueError('Original relative constants unsupported')
    blocks={}; cursor=base
    for line in lines:
        m=re.fullmatch(r'dcl_constantbuffer cb(\d+)\[(\d+)\], immediateIndexed',line)
        if m: blocks[int(m[1])]=(cursor,int(m[2])); cursor+=int(m[2])
    if cursor>128: raise ValueError('Per-source constant record overflow')
    temp=next(int(re.fullmatch(r'dcl_temps (\d+)',x)[1]) for x in lines if x.startswith('dcl_temps '))
    inputs=[int(x) for l in lines if l.startswith('dcl_input') for x in re.findall(r'\bv(\d+)\.',l)]
    outputs=[int(x) for l in lines if l.startswith('dcl_output') for x in re.findall(r'\bo(\d+)\.',l)]
    vin=max(inputs)+1; vout=max(outputs)+1 if stage=='vs' else None
    if stage=='ps': vin=3  # Original VS outputs occupy o0..o2; original PS reads v1/v2.
    if stage=='vs' and vout!=3: raise ValueError('Unexpected original VS linkage')
    transformed=[]; original_ops=[]; restored_ops=[]
    for line in lines:
        if line.startswith('dcl_constantbuffer '): continue
        if line.startswith('dcl_temps '):
            transformed+=['dcl_temps '+str(temp+1),'ishl r%d.x, v%d.x, l(7)'%(temp,vin)]
            if stage=='vs': transformed+=['mov o%d.x, v%d.x'%(vout,vin)]
            continue
        if not line.startswith(('dcl_','vs_','ps_')):
            original_ops.append(line)
            def constant(m):
                cb,index=map(int,m.groups()); offset,size=blocks[cb]
                if index>=size: raise ValueError('Constant index outside original declaration')
                return 'cb13[r%d.x + %d]'%(temp,offset+index)
            changed=re.sub(r'cb(\d+)\[(\d+)\]',constant,line)
            def restore(m):
                offset=int(m[1]); hit=[(cb,start,size) for cb,(start,size) in blocks.items() if start<=offset<start+size]
                if len(hit)!=1: raise ValueError('Ambiguous reverse mapping')
                cb,start,_=hit[0];return 'cb%d[%d]'%(cb,offset-start)
            restored_ops.append(re.sub(r'cb13\[r\d+\.x \+ (\d+)\]',restore,changed));line=changed
        transformed.append(line)
    if original_ops!=restored_ops: raise ValueError('Lighting instruction sequence changed')
    transformed.insert(1,'dcl_constantbuffer cb13[4096], dynamicIndexed')
    # D3D validators require canonical declaration order: inputs before outputs.
    at=next(i for i,x in enumerate(transformed) if x.startswith('dcl_output'))
    transformed.insert(at,'dcl_input_sgv v%d.x, instance_id'%vin if stage=='vs' else 'dcl_input_ps constant v%d.x'%vin)
    if stage=='vs':
        at=next(i for i,x in enumerate(transformed) if x.startswith('dcl_temps '))
        transformed.insert(at,'dcl_output o%d.x'%vout)
    return '\n'.join(transformed)+'\n',{'blocks':{str(k):{'offset':v[0],'vectors':v[1]} for k,v in blocks.items()},'endVector':cursor,'inputRegister':vin,'outputRegister':vout,'unchangedOriginalInstructions':len(original_ops)}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--audit',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--assembler',type=Path,required=True);parser.add_argument('--prefix',default='light');args=parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9-]+',args.prefix):raise ValueError('Invalid shader prefix')
    if args.output.exists(): raise ValueError('Refusing to overwrite experiment')
    audit=json.loads((args.audit/'passes.json').read_text());args.output.mkdir(parents=True)
    manifest={'status':'diagnostic shader candidates; runtime and pixel parity untested','strideVectors':128,'maximumSourcesPerDraw':32,'constantBufferSlot':13,'variants':[]}
    for n,g in enumerate(audit['selectedLightGroups']):
        if not g.get('stages') or not any(s['constantBlocks'] for s in g['stages'] if s['stage']=='ShaderStage.Pixel'): continue
        row={'name':g['name'],'sourceShader':g['shader'],'stages':{}};base=0
        for stage,source in [('vs',next(s for s in g['stages'] if s['stage']=='ShaderStage.Vertex')),('ps',next(s for s in g['stages'] if s['stage']=='ShaderStage.Pixel'))]:
            original=(args.audit/source['file']).read_bytes()
            if hashlib.sha256(original).hexdigest()!=source['sha256']:raise ValueError('Audit shader hash mismatch')
            stem=args.output/(args.prefix+str(n)+'-'+stage)
            copied=stem.with_suffix('.source.dxbc');copied.write_bytes(original)
            disassembly=subprocess.run([str(args.assembler),'-d',str(copied)],capture_output=True,text=True)
            if disassembly.returncode:raise RuntimeError('Cannot disassemble original shader: '+disassembly.stdout+disassembly.stderr)
            text=copied.with_suffix('.asm').read_text()
            asm,meta=rewrite(text,stage,base);base=meta['endVector']
            stem.with_suffix('.asm').write_text(asm)
            reflection=stem.with_suffix('.reflection.dxbc');reflection.write_bytes(signature_container(original,stage,meta['inputRegister'],meta['outputRegister']))
            result=subprocess.run([str(args.assembler),'-a','--copy-reflection',str(reflection),str(stem.with_suffix('.asm'))],capture_output=True,text=True)
            stem.with_suffix('.build.txt').write_text(result.stdout+result.stderr)
            binaries=list(args.output.glob(stem.name+'*.shdr'))
            if result.returncode or len(binaries)!=1: raise RuntimeError('Assembler rejected '+str(stem)+'; see build log')
            meta.update(sourceSha256=source['sha256'],candidate=str(binaries[0]),candidateSha256=hashlib.sha256(binaries[0].read_bytes()).hexdigest())
            row['stages'][stage]=meta
        manifest['variants'].append(row)
    (args.output/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps({'output':str(args.output),'variants':len(manifest['variants']),'status':manifest['status']}))
if __name__=='__main__':main()
