# License scope

The project's own source code, tools and original documentation are licensed
under MIT, as stated in `LICENSE`. Copyright: Ivan and KerbalOverEngineering
contributors, 2026. SPDX identifier: MIT.

Third-party materials retain their own licenses. MIT does not relicense NVIDIA,
Unity/KSP, other mods, original shader programs, recordings or game assets.

| Component | Terms | Distribution |
|---|---|---|
| KOE original C#/C++/Python/PowerShell and authored shaders | MIT | Source and binaries |
| NVIDIA Optical Flow interface headers | MIT, NVIDIA copyright notices retained | Two unmodified headers; declarations compiled into the bridge/probe |
| MinHook and bundled HDE | BSD-2-Clause notices in `MinHook-LICENSE.txt` | Statically linked into native modules |
| Deferred-derived instanced light shader assets | GPL-3.0, original copyright retained | Exact modified shader assets; full corresponding source archive supplied with the package |
| Instanced point-light plugin binary containing those shader assets | GPL-3.0 distribution conditions for the combined binary; KOE-authored source remains available under MIT | Isolated module; corresponding source included |
| EVE original shader bytecode | Original author's terms | Not distributed; a small KOE recipe transforms the user's installed exact shader in memory |
| NVIDIA display driver / nvofapi64.dll | NVIDIA driver terms | External installed dependency; not included or relicensed |
| Original KSP, Unity, other mods and SDK/tool archives | Their respective terms | External dependencies/developer reference materials, not covered by root MIT |

The package is an aggregate of separately identified components. `LICENSE`
must be retained with redistributed KOE-owned material. Third-party notices
and the GPL source archive must also be retained when redistributing the
associated binary components. Do not label the entire aggregate "MIT only".

See `licenses/THIRD-PARTY-NOTICES.md` and the exact license texts beside it.
