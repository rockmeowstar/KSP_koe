# NVIDIA Optical Flow API headers

Unmodified `nvOpticalFlowCommon.h` and `nvOpticalFlowD3D11.h` from NVIDIA
Optical Flow SDK 5.0.7, `NvOFInterface/`. Each file carries an explicit MIT
permission notice that applies to that header only. Original notices remain.

KOE uses these declarations to call `NvOFAPICreateInstanceD3D11` from the
installed driver's System32 `nvofapi64.dll`. No NVIDIA runtime DLL, SDK sample,
FRUC binary, CUDA library or driver installer is distributed with KOE.

The overall SDK license recognizes separately licensed components in section 7:
https://docs.nvidia.com/video-technologies/optical-flow-sdk/license/index.html

API documentation and hardware requirements:
https://docs.nvidia.com/video-technologies/optical-flow-sdk/nvofa-application-note/

This is an independent integration and does not imply NVIDIA endorsement.
