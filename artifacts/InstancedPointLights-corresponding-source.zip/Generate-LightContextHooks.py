"""Generate typed COM barriers from the installed SDK; no hand-written ABI guesses."""
import argparse,re,json,hashlib
from pathlib import Path

def strip_annotations(text):
    text=re.sub(r'/\*.*?\*/',' ',text,flags=re.S)
    result='';i=0
    while i<len(text):
        m=re.match(r'_[A-Za-z0-9_]+_',text[i:]) if i==0 or not (text[i-1].isalnum() or text[i-1]=='_') else None
        if not m:result+=text[i];i+=1;continue
        i+=len(m[0])
        while i<len(text) and text[i].isspace():i+=1
        if i<len(text) and text[i]=='(':
            level=1;i+=1
            while level:
                if text[i]=='(':level+=1
                if text[i]==')':level-=1
                i+=1
    return re.sub(r'\s+',' ',result).strip()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--sdk',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--shaders',type=Path,required=True);ap.add_argument('--extra-shaders',type=Path,action='append',default=[]);a=ap.parse_args()
    s=(a.sdk/'d3d11_3.h').read_text();start=s.index('typedef struct ID3D11DeviceContext4Vtbl');s=s[start:s.index('} ID3D11DeviceContext4Vtbl;',start)]
    methods=[]
    for ret,name,params in re.findall(r'(\w+)\s*\(\s*STDMETHODCALLTYPE\s*\*(\w+)\s*\)\s*\((.*?)\);',s,re.S):
        params=strip_annotations(params);args=[x.strip() for x in params.split(',')];names=[]
        for arg in args:
            match=re.search(r'(\w+)\s*(?:\[\s*\d*\s*\])?\s*$',arg)
            if not match:raise ValueError('Cannot parse '+name+': '+arg)
            names.append(match[1])
        if names[0]!='This':raise ValueError('Unexpected COM receiver')
        methods.append((ret,name,params,names))
    if len(methods)!=149 or methods[12][1]!='DrawIndexed' or methods[48][1]!='UpdateSubresource':raise ValueError('SDK layout changed: '+str(len(methods)))
    special={'DrawIndexed','Map','Unmap','UpdateSubresource','UpdateSubresource1','VSSetShader','PSSetShader'}
    allowed={'VSSetConstantBuffers','PSSetConstantBuffers','VSSetConstantBuffers1','PSSetConstantBuffers1'}
    cached={
        'IASetInputLayout':'key.Add(pInputLayout);',
        'IASetVertexBuffers':'key.Add(StartSlot); key.Add(NumBuffers); key.Array(ppVertexBuffers,NumBuffers); key.Array(pStrides,NumBuffers); key.Array(pOffsets,NumBuffers);',
        'IASetIndexBuffer':'key.Add(pIndexBuffer); key.Add(Format); key.Add(Offset);',
        'IASetPrimitiveTopology':'key.Add(Topology);',
        'PSSetShaderResources':'key.Add(StartSlot); key.Add(NumViews); key.Array(ppShaderResourceViews,NumViews);',
        'VSSetShaderResources':'key.Add(StartSlot); key.Add(NumViews); key.Array(ppShaderResourceViews,NumViews);',
        'PSSetSamplers':'key.Add(StartSlot); key.Add(NumSamplers); key.Array(ppSamplers,NumSamplers);',
        'VSSetSamplers':'key.Add(StartSlot); key.Add(NumSamplers); key.Array(ppSamplers,NumSamplers);',
        'RSSetState':'key.Add(pRasterizerState);',
        'RSSetViewports':'key.Add(NumViewports); key.Array(pViewports,NumViewports);',
        'RSSetScissorRects':'key.Add(NumRects); key.Array(pRects,NumRects);',
        'OMSetBlendState':'key.Add(pBlendState); key.Array(BlendFactor,4); key.Add(SampleMask);',
        'OMSetDepthStencilState':'key.Add(pDepthStencilState); key.Add(StencilRef);'
    }
    output=['// Generated from Windows SDK ID3D11DeviceContext4Vtbl. Do not edit.']
    hooks=[]
    for slot,(ret,name,params,names) in enumerate(methods):
        if slot<7 or (name.startswith('Get') or re.match(r'^(VS|PS|GS|HS|DS|CS|IA|OM|RS|SO)Get',name)):continue
        hooks.append((slot,name));output.append('using Fn_%s=%s(STDMETHODCALLTYPE*)(%s); static Fn_%s original_%s{};'%(name,ret,params,name,name))
        if name in special:continue
        if name in allowed:body='if(!inside) BeforeConstantBinding(This);'
        elif name in cached:body='if(Track(This)){StateKey key; '+cached[name]+' BeforeCached(This,'+str(slot)+',key);}else if(!inside){InvalidateCachedSlot(This,'+str(slot)+');}'
        else:body='if(!inside) Barrier(This);'
        if name=='ExecuteCommandList':body+=' if(!inside) InvalidateAllBuffers();'
        if name in {'ExecuteCommandList','ClearState','SwapDeviceContextState'}:body+=' if(!inside) InvalidateBindings(This);'
        if name not in special and 'pDstResource' in names:body+=' if(!inside) InvalidateBuffer(pDstResource);'
        if name not in special and 'pDstBuffer' in names:body+=' if(!inside) InvalidateBuffer(pDstBuffer);'
        output.append('static %s STDMETHODCALLTYPE Hook_%s(%s){%s %soriginal_%s(%s);}'%(ret,name,params,body,'return ' if ret!='void' else '',name,','.join(names)))
    output.append('static HookSpec contextHookSpecs[]={'+','.join('{%d,reinterpret_cast<void*>(Hook_%s),reinterpret_cast<void**>(&original_%s),"%s"}'%(slot,name,name,name) for slot,name in hooks)+'};')
    a.output.mkdir(parents=True,exist_ok=True);(a.output/'LightContextHooks.generated.h').write_text('\n'.join(output)+'\n')
    manifest=json.loads((a.shaders/'manifest.json').read_text());variants=manifest['variants'][:2];entries=[];files={}
    for extra in a.extra_shaders:variants+=json.loads((extra/'manifest.json').read_text())['variants']
    variants=list({v['stages']['ps']['sourceSha256']:v for v in variants}.values())
    for i,v in enumerate(variants):
        vs=v['stages']['vs'];ps=v['stages']['ps']
        if [b['vectors'] for b in vs['blocks'].values()]!=[3,6,4,21] or [b['vectors'] for b in ps['blocks'].values()]!=[6,8,22]:raise ValueError('Native constant layout requires a separate adapter for this shader')
        if vs['sourceSha256']!=variants[0]['stages']['vs']['sourceSha256']:raise ValueError('Native vertex identity differs')
        for stage in [vs,ps]:
            if hashlib.sha256(Path(stage['candidate']).read_bytes()).hexdigest()!=stage['candidateSha256']:raise ValueError('Candidate shader modified')
            name=Path(stage['candidate']).name;record={'source':str(Path(stage['candidate']).resolve()),'file':name,'sha256':stage['candidateSha256']}
            if name in files and files[name]['sha256']!=record['sha256']:raise ValueError('Shader filename collision')
            files[name]=record
        entries.append('{"'+vs['sourceSha256']+'","'+ps['sourceSha256']+'","'+vs['candidateSha256']+'","'+ps['candidateSha256']+'",L"'+Path(vs['candidate']).name+'",L"'+Path(ps['candidate']).name+'"}')
    (a.output/'LightShaders.generated.h').write_text('static ShaderSpec shaderSpecs[]={'+','.join(entries)+'};\n')
    (a.output/'runtime-shader-files.json').write_text(json.dumps(list(files.values()),indent=2))
    print(json.dumps({'methods':len(methods),'barriers':len(hooks),'shaderPairs':len(variants),'output':str(a.output)}))
if __name__=='__main__':main()
